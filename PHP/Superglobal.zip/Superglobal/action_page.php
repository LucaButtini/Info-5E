<?php




/*$fname= $_POST['fname'];
$lname= $_POST['lname'];*/

/*quando uso get tiro giù dati dal server e quando devo comunicare uso post.
Il get ha la query string, che manda in chiaro e si vedono nell'url del server

*/

//------------------------------------------------------------------------------------------------------------------------

/*ora voglio settare un cookie*/
// ogni coppia ha chiave-valore

setcookie('user', $_GET['fname']);

setCookie('bg-color', $_GET['color']);

$fname= $_GET['fname'];
$lname= $_GET['lname'];
echo $fname.'<br>';
echo $lname.'<br>';


